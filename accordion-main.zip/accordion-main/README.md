# accordion

- pure html and css

![preview-image](./preview.png)